# User Data Storage Directory

This directory is used to store user account information files.

## File Description
- `users.txt` - Stores user login information (username, password, etc.)
